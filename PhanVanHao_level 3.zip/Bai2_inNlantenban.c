#include <stdio.h>
main()
{
    int i=1,n;
    printf("Nhap so lan n :");
    scanf("%d",&n);
    while(i<=n)
    {printf("Phan Van Hao\t\t");i++;}
}

