
#include <stdio.h>
main()
{
    long int i=1,n,dem=0,k;
    printf("Nhap n,k:");
    scanf("%d%d",&n,&k);
    while(i<=n)
        {if (i%k==0) dem=dem+1;i++;}
    printf("co %d so nho hon %d chia het cho %d",dem,n,k);
}

