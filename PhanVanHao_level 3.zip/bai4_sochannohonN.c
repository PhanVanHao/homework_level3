#include <stdio.h>
main()
{
    long int i=1,n;
    printf("Nhap n :");
    scanf("%d",&n);
    printf("Cac so chan nho hon n la :\n");
    while(i<=n)
        {if (i%2==0) printf("%d\t",i);i++;}
}

