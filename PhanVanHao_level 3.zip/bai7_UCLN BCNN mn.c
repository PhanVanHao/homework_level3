#include <stdio.h>
main()
{
    int m,n,i,j;
    printf("Nhap m va n :");
    scanf("%d%d",&m,&n);
    for (i=n;i>=1;i--)
    {
        if (n==0||m==0 ) {printf("BCNN & UCLN = 0 "); return;}
        if((n%i)==0&&(m%i)==0) {printf("USCLN =%d",i);
        for (j=1;j<=999999;j++)
if ((j%n)==0&&(j%m)==0) {printf("\nBCNN cua %d va %d la %d",m,n,j);return (0);}
}}}

