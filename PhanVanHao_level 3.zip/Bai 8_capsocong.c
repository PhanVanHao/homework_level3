#include <stdio.h>
main()
{
    int n,k,x;
    printf ("nhap x , cong sai d : ");
    scanf("%d%d",&x,&k);
    printf("nhap n : ");
    scanf("%d",&n);
    printf("S(%d) = %d\nU(%d)=%d",n,n*(2*x+(n-1)*k)/2,n,n*(2*x+(n-1)*k)/2-x);
}
