
#include <stdio.h>
main()
{
    long int i=1,n,j,dem=0;
    printf("Nhap n :");
    scanf("%d",&n);
    printf("Cac so nguyen to nho hon n la :\n");
    while(i<=n)
        {for (j=1;j<=i;j++) if (i%j==0) dem=dem+1;
        if (dem==2) printf("%d\t",i);
        dem=0;
        i++;
        }
}

