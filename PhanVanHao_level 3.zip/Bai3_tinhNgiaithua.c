#include <stdio.h>
main()
{
    long int i=1,n,s=1;
    printf("Nhap n :");
    scanf("%d",&n);
    while(i<=n)
        {s=s*i;i++;}
    printf("n giai thua bang : %d",s);
}

