#include <stdio.h>
main()
{
    int n,k,x;
    printf ("nhap x , cong boi d : ");
    scanf("%d%d",&x,&k);
    printf("nhap n : ");
    scanf("%d",&n);
    if(k==1) printf("S(%d)=%d U(%d)=%d",1,n*x,1,n*x-x);
    else
    printf("S(%d) = %f\nU(%d)=%f",n,(float)x*(1-pow(k,n+1))/(1-k),n,(float)x*(1-pow(k,n+1))/(1-k)-x);
}
